# Installation
Execute `npm i` in this directory.

# Configuration

Open app.js and add the appropriate Cloudinary details where marked in the top of the file.  You may need to create a preset in the cloudinary console.

# Run the application
Use your favorite http server, such as the live-server plugin in Visual Studio Code to open `index.html`.

Otherwise, execute `npx http-server .` from this directory, and then open the local server at the URL returned by the previous command. 