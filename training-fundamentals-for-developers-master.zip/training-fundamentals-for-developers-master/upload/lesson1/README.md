# Installation
Execute `npm i`


# Run the application
Execute `node upload/lesson1/example#` from the root project folder.