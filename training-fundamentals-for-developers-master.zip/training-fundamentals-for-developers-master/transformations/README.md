1. Go to this directory in the project and run 'npm i' in your Terminal/Command Line Interface (CLI). This will install any necessary dependancies.

2. Go to the root folder of the project and run 'node transformations/responsive-breakpoints.js' to upload the required image to your Cloudinary account.

3. Insert your cloud name into the w-auto-example.html file, specifically on lines 50 and 75.

4. Insert your cloud name into the breakpoints.html file, specifically on lines 51-55 and line 82.

5. Go to the transformations directory and run 'node server.js'. 

6. Visit localhost:8080/w-auto-example.html in your browser to view the w_auto example.

7. Visit localhost:8080/breakpoints.html in your browser to view the responsive breakpoints example.
